
class Triangle{
  constructor(){
    this.type = 'triangle';
    this.position = [0.0,0.0,0.0];
    this.color = [1.0,1.0,1.0,1.0];
    this.size = 5.0;
    this.vertDist = 1;
    this.height = 1;
  }

  render(){
    var xy = this.position;
    var rgba = this.color;
    var size = this.size;

    //var xy = g_points[i];
    //var rgba = g_colors[i];
    //var size = g_sizes[i];

    // Pass the position of a point to a_Position variable
    //gl.vertexAttrib3f(a_Position, xy[0], xy[1], 0.0);
    // Pass the color of a point to u_FragColor variable
    gl.uniform4f(u_FragColor, rgba[0], rgba[1], rgba[2], rgba[3]);
    // Pass the size of the point to u_Size variable
    gl.uniform1f(u_Size, size);
    // Draw
    //gl.drawArrays(gl.TRIANGLES, 0, 1);
    var d = this.size/200.0;
    var spread = this.vertDist / 500.0;
    var height = this.height / 500.0;
    drawTriangle( [xy[0] - d - spread, xy[1] - d, 
                   xy[0] + d + spread, xy[1] - d, 
                   xy[0]  , xy[1] + height]);
  }
}

function drawTriangle(vertices){
    var n = 3; //standard number of vertices

    var vertexBuffer = gl.createBuffer();
    if(!vertexBuffer){
        console.log('Failed to create the buffer object');
        return -1;
    }

    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.DYNAMIC_DRAW);

    gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_Position);
    gl.drawArrays(gl.TRIANGLES, 0, n);

}

function drawTriangle3D(vertices){
    var n = 3; //standard number of vertices

    var vertexBuffer = gl.createBuffer();
    if(!vertexBuffer){
        console.log('Failed to create the buffer object');
        return -1;
    }

    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.DYNAMIC_DRAW);

    gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_Position);
    gl.drawArrays(gl.TRIANGLES, 0, n);

}

function drawPreviewTriangle(xy){
    // draw with half opacity to show it's a preview
    var rgba = g_selectedColor;
    gl.uniform4f(u_FragColor, rgba[0], rgba[1], rgba[2], 0.5); // 0.5 alpha = semi transparent

    var d = g_selectedSize / 200.0;
    var spread = g_selectedVertDist / 500.0;
    var height = g_selectedHeight / 500.0;

    drawTriangle([
        xy[0] - d - spread, xy[1] - d,
        xy[0] + d + spread, xy[1] - d,
        xy[0],              xy[1] + height
    ]);
}